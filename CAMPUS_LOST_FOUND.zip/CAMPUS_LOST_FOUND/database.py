import sqlite3

DATABASE = "campus.db"


# =========================
# CREATE DATABASE
# =========================

def create_database():

    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()


    # USERS TABLE

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            name TEXT NOT NULL,

            email TEXT NOT NULL UNIQUE,

            password TEXT NOT NULL

        )
    """)


    # ITEMS TABLE

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS items (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            user_id INTEGER NOT NULL,

            item_type TEXT NOT NULL,

            item_name TEXT NOT NULL,

            description TEXT NOT NULL,

            location TEXT NOT NULL,

            date TEXT NOT NULL,

            category TEXT NOT NULL,

            FOREIGN KEY (user_id)
            REFERENCES users(id)

        )
    """)


    connection.commit()

    connection.close()


# =========================
# ADD USER
# =========================

def add_user(name, email, password):

    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO users
        (name, email, password)

        VALUES (?, ?, ?)
    """, (
        name,
        email,
        password
    ))

    connection.commit()

    connection.close()


# =========================
# CHECK LOGIN
# =========================

def check_user(email, password):

    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute("""
        SELECT *
        FROM users

        WHERE email = ?
        AND password = ?
    """, (
        email,
        password
    ))

    user = cursor.fetchone()

    connection.close()

    return user


# =========================
# ADD ITEM
# =========================

def add_item(
    user_id,
    item_type,
    item_name,
    description,
    location,
    date,
    category
):

    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO items
        (
            user_id,
            item_type,
            item_name,
            description,
            location,
            date,
            category
        )

        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        user_id,
        item_type,
        item_name,
        description,
        location,
        date,
        category
    ))

    connection.commit()

    connection.close()


# =========================
# GET ALL ITEMS
# =========================

def get_items():

    connection = sqlite3.connect(DATABASE)

    connection.row_factory = sqlite3.Row

    cursor = connection.cursor()

    cursor.execute("""
        SELECT *
        FROM items

        ORDER BY id DESC
    """)

    items = cursor.fetchall()

    connection.close()

    return items


# =========================
# GET MY ITEMS
# =========================

def get_my_items(user_id):

    connection = sqlite3.connect(DATABASE)

    connection.row_factory = sqlite3.Row

    cursor = connection.cursor()

    cursor.execute("""
        SELECT *
        FROM items

        WHERE user_id = ?

        ORDER BY id DESC
    """, (user_id,))

    items = cursor.fetchall()

    connection.close()

    return items


# =========================
# RUN DATABASE
# =========================

create_database()