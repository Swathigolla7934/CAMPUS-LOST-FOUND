from flask import Flask, render_template, request, redirect, url_for, session

from database import (
    add_user,
    check_user,
    add_item,
    get_items,
    get_my_items
)


app = Flask(__name__)

app.secret_key = "campus_lost_found_secret"


# =========================
# HOME
# =========================

@app.route("/")
def home():

    items = get_items()

    return render_template(
        "index.html",
        items=items
    )


# =========================
# LOGIN
# =========================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]

        user = check_user(
            email,
            password
        )

        if user:

            session["user_id"] = user[0]

            session["user_name"] = user[1]

            return redirect(
                url_for("dashboard")
            )

        return render_template(
            "auth.html",
            login_message="Invalid email or password!"
        )

    return render_template("auth.html")


# =========================
# REGISTER
# =========================

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        name = request.form["name"]

        email = request.form["email"]

        password = request.form["password"]

        try:

            add_user(
                name,
                email,
                password
            )

            return render_template(
                "auth.html",
                register_message=
                "Registration successful! You can login now."
            )

        except Exception:

            return render_template(
                "auth.html",
                register_message=
                "Email already registered!"
            )

    return render_template("auth.html")


# =========================
# LOGOUT
# =========================

@app.route("/logout")
def logout():

    session.clear()

    return redirect(
        url_for("home")
    )


# =========================
# DASHBOARD
# =========================

@app.route("/dashboard")
def dashboard():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    # Get only logged-in user's reports

    my_items = get_my_items(
        session["user_id"]
    )

    return render_template(
        "dashboard.html",
        name=session["user_name"],
        items=my_items
    )


# =========================
# REPORT LOST ITEM
# =========================

@app.route("/lost", methods=["GET", "POST"])
def lost_item():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    if request.method == "POST":

        item_name = request.form["item_name"]

        description = request.form["description"]

        location = request.form["location"]

        date = request.form["date"]

        category = request.form["category"]


        # Store item with logged-in user's ID

        add_item(
            session["user_id"],
            "Lost",
            item_name,
            description,
            location,
            date,
            category
        )

        return redirect(
            url_for("dashboard")
        )

    return render_template(
        "lost.html"
    )


# =========================
# REPORT FOUND ITEM
# =========================

@app.route("/found", methods=["GET", "POST"])
def found_item():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    if request.method == "POST":

        item_name = request.form["item_name"]

        description = request.form["description"]

        location = request.form["location"]

        date = request.form["date"]

        category = request.form["category"]


        # Store item with logged-in user's ID

        add_item(
            session["user_id"],
            "Found",
            item_name,
            description,
            location,
            date,
            category
        )

        return redirect(
            url_for("dashboard")
        )

    return render_template(
        "found.html"
    )


# =========================
# VIEW ALL ITEMS
# =========================

@app.route("/items")
def items():

    all_items = get_items()

    return render_template(
        "items.html",
        items=all_items
    )


# =========================
# HELP PAGE
# =========================

@app.route("/help")
def help_page():

    if "user_id" not in session:

        return redirect(
            url_for("login")
        )

    return render_template(
        "help.html"
    )


# =========================
# RUN APPLICATION
# =========================

if __name__ == "__main__":

    app.run(debug=True)